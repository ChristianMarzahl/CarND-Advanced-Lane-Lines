import numpy as np
import cv2

from util.CamCalibration import CameraCalibration
from util.PerspectiveTransformation import PerspectiveTransformation
from util.ThresholdRoadImage import ThresholdRoadImage
from util.Line import Line
from util.Line import LineType

class LaneDetector(object):
    """description of class"""

    def __init__(self, camera_calibration, perspective_transformation, threshold_road_image ):

        self.camera_calibration = camera_calibration
        self.perspective_transformation = perspective_transformation
        self.threshold_road_image = threshold_road_image

        self.left_line = Line(LineType.LeftLine)
        self.right_line = Line(LineType.RightLine)

        self.image_offset = 250
        self.dists = []
        # 
        self.line_segments = 9


    def process_frame(self, frame):
        
        input_frame = np.copy(frame)
        
        debug_dictionary = {"Input":input_frame}

        # undistort image 
        undist_image = self.camera_calibration.undistort_image(frame)
        debug_dictionary.update({"undistort_image":undist_image})

        # perspective transformation
        warped_image = self.perspective_transformation.apply(undist_image)
        debug_dictionary.update({"warped_image":warped_image})

        # threshold image 
        threshold_image = self.threshold_road_image.compute_threshold(warped_image)
        debug_dictionary.update({"threshold_image":threshold_image})

        self.left_line.update_line(threshold_image, debug_dictionary)
        self.right_line.update_line(threshold_image, debug_dictionary)

        # draw the current best fit if it exists
        if self.left_line.best_fit is not None and self.right_line.best_fit is not None:
            result =  self.draw_lane(input_frame,threshold_image,self.left_line.best_fit,self.right_line.best_fit)  
            rad_l, rad_r, d_center = self.calc_curv_rad_and_center_dist(threshold_image, self.left_line.best_fit, self.right_line.best_fit, self.left_line.lane_inds, self.right_line.lane_inds)

            result = self.draw_data(result,(rad_l+rad_r)/2, d_center)
            return result
        
        return input_frame

    def draw_lane(self, original_img, binary_img, l_fit, r_fit):

        new_img = np.copy(original_img)
        if l_fit is None or r_fit is None:
            return original_img
        # Create an image to draw the lines on
        warp_zero = np.zeros_like(binary_img).astype(np.uint8)
        color_warp = np.dstack((warp_zero, warp_zero, warp_zero))
    
        h,w = binary_img.shape
        ploty = np.linspace(0, h-1, num=h)# to cover same y-range as image
        left_fitx = l_fit[0]*ploty**2 + l_fit[1]*ploty + l_fit[2]
        right_fitx = r_fit[0]*ploty**2 + r_fit[1]*ploty + r_fit[2]

        # Recast the x and y points into usable format for cv2.fillPoly()
        pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
        pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
        pts = np.hstack((pts_left, pts_right))

        # Draw the lane onto the warped blank image
        cv2.fillPoly(color_warp, np.int_([pts]), (0,255, 0))
        cv2.polylines(color_warp, np.int32([pts_left]), isClosed=False, color=(255,0,255), thickness=15)
        cv2.polylines(color_warp, np.int32([pts_right]), isClosed=False, color=(0,255,255), thickness=15)

        # Warp the blank back to original image space using inverse perspective matrix (Minv)
        newwarp = self.perspective_transformation.apply_inv(color_warp) 

        # Combine the result with the original image
        result = cv2.addWeighted(new_img, 1, newwarp, 0.5, 0)
        return result

    def calc_curv_rad_and_center_dist(self, bin_img, l_fit, r_fit, l_lane_inds, r_lane_inds):
        # Define conversions in x and y from pixels space to meters
        ym_per_pix = 30/720 # 30/720# 3.048/100 # meters per pixel in y dimension, lane line is 10 ft = 3.048 meters
        xm_per_pix = 3.7/700 # 3.7/660# 3.7/378 # meters per pixel in x dimension, lane width is 12 ft = 3.7 meters
        left_curverad, right_curverad, center_dist = (0, 0, 0)

        # Define y-value where we want radius of curvature
        ploty = np.linspace(0, bin_img.shape[0]-1, bin_img.shape[0])
        y_eval = np.max(ploty)
  
        nonzero = bin_img.nonzero()
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        # Extract left and right line pixel positions
        leftx = nonzerox[l_lane_inds]
        lefty = nonzeroy[l_lane_inds] 
        rightx = nonzerox[r_lane_inds]
        righty = nonzeroy[r_lane_inds]
    
        if len(leftx) != 0 and len(rightx) != 0:
            # Fit new polynomials to x,y in world space
            left_fit_cr = np.polyfit(lefty*ym_per_pix, leftx*xm_per_pix, 2)
            right_fit_cr = np.polyfit(righty*ym_per_pix, rightx*xm_per_pix, 2)
            # Calculate the new radii of curvature
            left_curverad = ((1 + (2*left_fit_cr[0]*y_eval*ym_per_pix + left_fit_cr[1])**2)**1.5) / np.absolute(2*left_fit_cr[0])
            right_curverad = ((1 + (2*right_fit_cr[0]*y_eval*ym_per_pix + right_fit_cr[1])**2)**1.5) / np.absolute(2*right_fit_cr[0])
            # Now our radius of curvature is in meters
    
        # Distance from center is image x midpoint - mean of l_fit and r_fit intercepts 
        if r_fit is not None and l_fit is not None:
            car_position = bin_img.shape[1]/2
            l_fit_x_int = l_fit[0]*bin_img.shape[0]**2 + l_fit[1]*bin_img.shape[0] + l_fit[2]
            r_fit_x_int = r_fit[0]*bin_img.shape[0]**2 + r_fit[1]*bin_img.shape[0] + r_fit[2]
            lane_center_position = (r_fit_x_int + l_fit_x_int) /2
            center_dist = (car_position - lane_center_position) * xm_per_pix
        return left_curverad, right_curverad, center_dist

    def draw_data(self, original_img, curv_rad, center_dist):
        new_img = np.copy(original_img)
        h = new_img.shape[0]
        font = cv2.FONT_HERSHEY_DUPLEX
        text = 'Curve radius: ' + '{:04.2f}'.format(curv_rad) + 'm'
        cv2.putText(new_img, text, (40,70), font, 1.5, (200,255,155), 2, cv2.LINE_AA)
        direction = ''
        if center_dist > 0:
            direction = 'right'
        elif center_dist < 0:
            direction = 'left'
        abs_center_dist = abs(center_dist)
        text = '{:04.3f}'.format(abs_center_dist) + 'm ' + direction + ' of center'
        cv2.putText(new_img, text, (40,120), font, 1.5, (200,255,155), 2, cv2.LINE_AA)
        return new_img